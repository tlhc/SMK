/*
 * =====================================================================================
 *
 *       Filename:  wapperprintf.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年02月07日 10时01分42秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>


void callback(void *x) {

    int a = *(int*)x;
    while(1) {
        printf("%s---%d\n", "thread", a);
        sleep(1);
    }


}


#define O_PRINT(...) \
    do \
    {  \
    printf(__VA_ARGS__); \
    }  \
    while(0);

int main(int argc, char *argv[]) {
    O_PRINT("%s", "fdfdasfasfdas");


    pthread_t thead1;
    int a = 1;
    pthread_create(&thead1, NULL, (void *)callback, (void*)&a);
    pthread_join(thead1, NULL);
    return 0;
}
