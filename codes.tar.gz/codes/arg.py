from sys import argv

script, first, second, thrid = argv

print "src name is : " + script
print "1 arg is : " + first
print "2 arg is : " + second
print "3 arg is : " + thrid
