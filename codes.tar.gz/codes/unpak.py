from sys import argv

scripts, arg1, arg2, arg3 = argv

print "s", scripts
print "1", arg1
print "2", arg2
print "3", arg3
