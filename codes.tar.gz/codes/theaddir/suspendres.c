/*
 * =====================================================================================
 *
 *       Filename:  suspendres.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年02月08日 14时07分25秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
pthread_cond_t cond2 = PTHREAD_COND_INITIALIZER;

int g_flag = 1;
int g_flag2 = 0;
int g_cnt = 0;
void pcall1(void *x) {
    while(1) {
        pthread_mutex_lock(&mutex);
        int tid = *(int*)x;
        while(!g_flag) {
            pthread_cond_wait(&cond, &mutex);
        }
        int cnt = 0;
        while(cnt < 100) {
            cnt++;
            g_cnt++;
        }
        sleep(1);
        printf("%s---->%d---->%d\n", "thread", tid, g_cnt);
        g_flag2 = 1;
        pthread_mutex_unlock(&mutex);
        pthread_cond_signal(&cond2);

    }
}


void pcall2(void *x) {
    while(1) {
        pthread_mutex_lock(&mutex);
        int tid = *(int*)x;
        while(!g_flag2) {
            pthread_cond_wait(&cond2, &mutex);
        }
        int cnt = 0;
        while(cnt < 100) {
            cnt++;
            g_cnt++;
        }
        sleep(1);
        printf("%s---->%d---->%d\n", "thread", tid, g_cnt);
        g_flag = 1;
        pthread_mutex_unlock(&mutex);
        pthread_cond_signal(&cond);
    }
}

int main(int argc, char *argv[]) {

    pthread_t p1, p2;
    int a = 1;
    int b = 2;
    int ret = pthread_create(&p1, NULL, (void*)pcall1, (void*)&a);
    int ret2 = pthread_create(&p2, NULL, (void*)pcall2, (void*)&b);

    pthread_join(p1, NULL);
    pthread_join(p2, NULL);

    return 0;
}
