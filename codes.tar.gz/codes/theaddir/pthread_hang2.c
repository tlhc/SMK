/*
 * =====================================================================================
 *
 *       Filename:  pthread_hang2.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年02月08日 15时56分15秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <semaphore.h>
void * thread1(void);
void * thread2(void);
void thread1_suspend(int);
void thread1_resume(int);

pthread_mutex_t mp = PTHREAD_MUTEX_INITIALIZER;

int main()
{
    pthread_t p1;
    pthread_mutex_lock(&mp);
    pthread_create(&p1, NULL, (void *)thread1, NULL);
    sleep(5);
    printf("main thread kill SIGUSR1\n");
    fflush(stdout);
    pthread_kill(p1, SIGUSR1);
    sleep(5);


    pthread_kill(p1, SIGUSR2);

    sleep(5);

    for(;;);
    //pthread_mutex_unlock(&mp);
    //pthread_kill(p1, SIGCONT);
    //pthread_mutex_destroy(&mp);

    //pthread_join(p1, NULL);
    //pthread_join(p2, NULL);
}

void * thread1(void)
{
    int i = 0,j=0,k=0;
    signal(SIGUSR1, thread1_suspend);
    signal(SIGUSR2, thread1_resume);
    for(;;)
    {
        printf("thread1 is running! i=%d, j=%d, k=%d\n", i, j, k);
        k++;
        fflush(stdout);
        for(i=0; i<10000; i++)
            for(j=0; j<10000; j++);
    }
}

void thread1_suspend(int a)
{
    printf("thread1_suspend lock mutex\n");
    pthread_mutex_lock(&mp);
    pthread_mutex_lock(&mp); //形成死锁，等待。。。。。
}

void thread1_resume(int a)
{
    printf("thread1_suspend unlock mutex\n");
    pthread_mutex_unlock(&mp);    
    pthread_mutex_unlock(&mp);    
}
