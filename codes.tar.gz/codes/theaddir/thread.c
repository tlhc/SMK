/*
 * =====================================================================================
 *
 *       Filename:  thread.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年02月07日 11时32分13秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex2 = PTHREAD_MUTEX_INITIALIZER;

pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
int signal_d = 0;

void callback1(void *x) {

    pthread_mutex_lock(&mutex);
    int a = *(int*)x;
    int cnt = 0;
    while(1) {
        printf("%s-----%d-----%d\n", "thread", a, cnt);
        usleep(1000);
        cnt++;
        if(cnt > 100) {
            signal_d = 1;
            pthread_mutex_unlock(&mutex);
            pthread_cond_signal(&cond);
            //pthread_cond_broadcast(&cond);
            return;
        }
    }
    pthread_mutex_unlock(&mutex);
    pthread_cond_signal(&cond);
}


void callback2(void *x) {

    printf("%s--%d\n", "call", *(int*)x);
    pthread_mutex_lock(&mutex);
    printf("%s\n", "start ...wait cond");

    while(signal_d == 0) {
        printf("------->%d\n", signal_d);
        pthread_cond_wait(&cond, &mutex);
    }
    int a = *(int*)x;
    int cnt = 0;
    while(1) {
        printf("%s-----%d-----%d\n", "thread", a, cnt);
        usleep(1000);
        cnt++;
        if(cnt > 100) {
            signal_d = 1;
            pthread_mutex_unlock(&mutex);
            pthread_cond_signal(&cond);
            return;
        }
    }
    pthread_mutex_unlock(&mutex);
}



int main(int argc, char *argv[]) {

//    pthread_mutex_t mutex;
//    pthread_mutex_init(&mutex, NULL);


    int b = 2;
    pthread_t thread2;
    pthread_create(&thread2, NULL, (void*)callback2, (void*)(&b));

    int c = 3;
    pthread_t thread3;
    pthread_create(&thread3, NULL, (void*)callback2, (void*)(&c));



    pthread_t thread1;
    int a = 1;
    pthread_create(&thread1, NULL, (void*)callback1, (void*)(&a));


    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);
    pthread_join(thread3, NULL);
    return 0;
}
