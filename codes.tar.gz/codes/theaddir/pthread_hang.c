/*
 * =====================================================================================
 *
 *       Filename:  pthread_hang.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年02月08日 15时45分41秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */
#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <semaphore.h>
void * thread1(void);
void * thread2(void);
void thread1_suspend(int);

pthread_mutex_t mp = PTHREAD_MUTEX_INITIALIZER;


int suspendTarget(pthread_mutex_t *mp, pthread_t p1) {
    pthread_mutex_lock(mp);
    pthread_kill(p1, SIGUSR1);
}

int resumeTarget(pthread_mutex_t *mp) {
    pthread_mutex_unlock(mp);
}

int main()
{
    pthread_t p1;
    pthread_mutex_lock(&mp);
    pthread_create(&p1, NULL, (void *)thread1, NULL);
    sleep(5);
    printf("main thread kill SIGUSR1\n");
    fflush(stdout);
    pthread_kill(p1, SIGUSR1);
    sleep(5);
    pthread_mutex_unlock(&mp);
    //pthread_kill(p1, SIGCONT);


    sleep(5);
    printf("%s\n", "suspend again");

    pthread_mutex_lock(&mp);
    pthread_kill(p1, SIGUSR1);

    printf("%s\n", "--------");
    sleep(5);


    printf("%s\n", "resume thread");

    pthread_mutex_unlock(&mp);


    int cnt = 0;
    while(1) {
        cnt++;
        if(cnt % 2 == 0) {
            suspendTarget(&mp, p1);
        } else {
            resumeTarget(&mp);
        }
        usleep(1000000);
    }

    pthread_mutex_destroy(&mp);
   // for(;;);

    pthread_join(p1, NULL);
}


void thread1_suspend(int a)
{
    printf("thread1_suspend lock mutex\n");
    pthread_mutex_lock(&mp);
    printf("thread1_suspend unlock mutex\n");
    pthread_mutex_unlock(&mp);

}


void * thread1(void)
{
    int i = 0,j=0,k=0;
    signal(SIGUSR1, thread1_suspend);
    for(;;)
    {
        printf("thread1 is running! i=%d, j=%d, k=%d\n", i, j, k);
        k++;
        fflush(stdout);
        for(i=0; i<10000; i++)
            for(j=0; j<10000; j++);
    }
}


