/*
 * =====================================================================================
 *
 *       Filename:  unlink.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年01月22日 13时41分23秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

/*  
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>

int main(int argc, char *argv[]) {
    int fd = open("./outfile", O_RDWR|O_CREAT);
    unlink("./outfile");
    printf("%s\n", "sleep");
    sleep(30);
    int n = write(fd, "1111111111111111111111111111", 20);
    if(n != 20) {
        printf("%s\n", "write error");
    }

    printf("%s\n", "read the unlink file");
    char buf[20];
    memset(buf, '\0', 20);
    int n1 = read(fd, buf, 20);
    if(n1 != 20) {
        printf("%s\n", "read error");
        printf("%d\n", n1);
    }

    printf("%s\n", "read contnent");
    printf("%s\n", buf);

    return 0;
}

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <err.h>

int main(int argc, char *argv[])
{
    int fd;
    fd = open("tempfile", O_RDWR|O_CREAT, S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH);
    if (fd < 0)
        errx(1, "open error");

    /*  
    if (unlink("tempfile") < 0)
        errx(1, "unlink error");
        */
    printf("%s\n","remove @@@@" );
    if(remove("tempfile") < 0) {
        errx(1, "rm error");
    }
    printf("file unlinked\n");

    printf("%s\n", "write file");
    int n = write(fd, "fdsafdsafdsafsa", 15);
    printf("%s%d\n", "the wite cont", n);

    printf("%s\n", "-----------");
    printf("%s\n", "read");
    char buf[15];
    char *pbuf = (char *)malloc(sizeof(char) * 20);
    memset(buf, '\0', 15);
    lseek(fd, 0 , SEEK_SET); //!!!!!!!!!!!!!!!!!!!!!!!!!!1
    read(fd, pbuf, 15);

    int i;
    printf("%s\n", pbuf);
    sleep(5);

    printf("done\n");

    exit(0);
}



