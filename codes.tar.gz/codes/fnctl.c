/*
 * =====================================================================================
 *
 *       Filename:  fnctl.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年01月21日 13时32分51秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    if(argc != 2) {
        printf("%s\n", "please input em argc");
        return 0;
    }
    int ret = fcntl(atoi(argv[1]), F_GETFL, 0);
    if(ret < 0) {
        printf("%s\n", "unable to get fl");
    }
    int accmode = ret & O_ACCMODE;
    if(accmode == O_RDWR) {
        printf("%s\n", "rw");
    } else if(accmode == O_RDONLY) {
        printf("%s\n", "r");
    } else if(accmode == O_WRONLY) {
        printf("%s\n", "w");
    }
    if(ret & O_APPEND) {
        printf("%s\n", "append");
    } else if(ret & O_NONBLOCK) {
        printf("%s\n", "none block");
    }
    return 0;
}
