/*
 * =====================================================================================
 *
 *       Filename:  ftream.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年01月22日 16时26分25秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define MAX 1024
int main(int argc, char *argv[]) {
    char buf[MAX];
    FILE *fp;
    memset(buf, '\0', MAX);
    fp = fopen("stream", "a+");
    if(fp == NULL) {
        printf("%s\n", "open failed");
    }
    while(fgets(buf, MAX, stdin) != NULL) {
        printf("--->%s\n", buf);
        if(fwrite(buf, strlen(buf) + 1, 1, fp) != 1) {
            printf("%s\n", "stream write error");
        }
        fflush(fp); //!!!!!刷新流缓冲！！！！！
    }
    return 0;
}
