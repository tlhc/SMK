/*
 * =====================================================================================
 *
 *       Filename:  rw.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年01月22日 17时12分36秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

typedef struct _s1 {
    int a;
    double b;
    char c;
} S1;


int main(int argc, char *argv[]) {
    FILE *fp = fopen("file", "w+");
    if(fp == NULL) {
        printf("%s\n", "file open error");
        return 0;
    }
    S1 s = {
        .a = 1,
        .b = 0.2, 
        .c = 'c'
    };

    S1 s1 = {
        .a = 2,
        .b = 0.3, 
        .c = 'd'
    };

    int ret = fwrite(&s, sizeof(s), 1, fp);
    if(ret != 1) {
        printf("%s\n", "write error");
    }

    ret = fwrite(&s1, sizeof(s), 1, fp);

    if(ret != 1) {
        printf("%s\n", "write error");
    }
    fflush(fp);
    fclose(fp);

    printf("%s\n", "-----read------");
    fp = fopen("file", "r");
    S1 sread;
    if(fread(&sread, sizeof(sread), 1, fp) != 1) {
        printf("%s\n", "read error");
    }

    printf("%s\n", "CONTENT");
    printf("%d\n", sread.a);
    printf("%f\n", sread.b);
    printf("%c\n", sread.c);

    if(fread(&sread, sizeof(sread), 1, fp) != 1) {
        printf("%s\n", "read error");
    }

    printf("%s\n", "CONTENT");
    printf("%d\n", sread.a);
    printf("%f\n", sread.b);
    printf("%c\n", sread.c);


    printf("%s\n", "rewind");
    rewind(fp);

    fpos_t pos;
    fgetpos(fp, &pos);                          /* save the pos */

    printf("%s\n", "read");
    fseek(fp, sizeof(S1), SEEK_SET);
    if(fread(&sread, sizeof(sread), 1, fp) != 1) {
        printf("%s\n", "seek read error");
    }
    printf("%s\n", "CONTENT");
    printf("%d\n", sread.a);
    printf("%f\n", sread.b);
    printf("%c\n", sread.c);

    fsetpos(fp, &pos);
    double aa = 3.0;
    int off = (int)(&((S1*)0)->b);
    fseek(fp, off, SEEK_SET);
    fwrite((void*)&aa, sizeof(double), 1, fp);
    fflush(fp);
    rewind(fp);
    printf("%s\n", "after modify");

    if(fread(&sread, sizeof(sread), 1, fp) != 1) {
        printf("%s\n", "seek read error");
    }
    printf("%s\n", "CONTENT");
    printf("%d\n", sread.a);
    printf("%f\n", sread.b);
    printf("%c\n", sread.c);

    fclose(fp);
    return 0;
}
