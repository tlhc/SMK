/*
 * =====================================================================================
 *
 *       Filename:  calloc.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年01月23日 14时22分02秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

int main(int argc, char *argv[]) {
#if 0
    int *p = (int *)calloc(sizeof(int), 10);
    int i = 0;
    for (i = 0; i < 10; ++i) {
        *(p + i) = i;
    }
    int j = 0;
    for (j = 0; j < 10; ++j) {
        printf("%d\n", *(p + j));
    }
#endif

#if 0
    int *p = (int *)malloc(10);
    int i = 0;
    for (i = 0; i < 10; ++i) {
        *(p + i) = i;
    }

    int j = 0;
    for (j = 0; j < 10; ++j) {
        printf("%d\n", *(p + j));
    }
#endif

    char *p = (char *)alloca(1000);
    int i = 0;
    char *q = p;
    for (i = 0; i < 100; ++i) {
        sprintf(q, "--%d", i);
        if(i >= 10 && i < 99) {
            q += 4;
        } else {
            q+=3;
        }

    }
    printf("%s\n", p);
    return 0;
}
