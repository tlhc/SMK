/*
 * =====================================================================================
 *
 *       Filename:  stat.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年01月22日 13时07分59秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>

int main(int argc, char *argv[]) {
    struct stat buf;
    char *ptr;
    int i;
    for (i = 0; i < argc; ++i) {
        if(lstat(argv[i], &buf) < 0) {
            printf("%s\n", "error");
            continue;
        }
        if(S_ISRE(buf.st_mode)) {

        } else if(S_ISDIR(buf.st_mode)){

        } else if(S_ISDIR)
    }
    return 0;
}
