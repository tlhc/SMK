promote = '> '
a = raw_input(promote)
b = raw_input(promote)

print "a b"
print a
print b

