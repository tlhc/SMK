/*
 * =====================================================================================
 *
 *       Filename:  gethostname.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年01月23日 13时07分16秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[]) {

    char *p = NULL;
    p = (char*) malloc( sizeof(char) * 1000);
    if ( p==NULL ) {
        fprintf ( stderr, "\ndynamic memory allocation failed\n" );
        exit (EXIT_FAILURE);
    }


    gethostname(p, 1000);
    printf("%s\n",p);
    free ( p );
    p	= NULL;

    return 0;
}
