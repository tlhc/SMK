/*
 * =====================================================================================
 *
 *       Filename:  seekset.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年01月21日 10时17分17秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    if(lseek(STDIN_FILENO, 0, SEEK_CUR) == -1) {
        printf("%s\n", "can't seek");
    } else {
        printf("%s\n", "seek ok");
    }
    return 0;
}
