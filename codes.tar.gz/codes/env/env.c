/*
 * =====================================================================================
 *
 *       Filename:  env.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年01月23日 14时51分43秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

int main(int argc, char *argv[]) {

    char *env = getenv("PATH");
    if(env == NULL) {
        printf("%s\n","null path" );
    }
    printf("%s\n", env);

    env = NULL;
    env = getenv("PWD");
    if(env == NULL) {
        printf("%s\n","no pass" );
    }
    printf("%s\n", env);

    return 0;
}
