from sys import argv

s, src, dst = argv

content = ""

def openread(src):
    fd = open(src)
    global content
    content = fd.read()
    fd.seek(0)
    print fd.read()
    fd.close()


def writefile(dst):
    global content
    fd1 = open(dst, 'w')
    print content
    fd1.write(content)
    fd1.close()

openread(src)
writefile(dst)




