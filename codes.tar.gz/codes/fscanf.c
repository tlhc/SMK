/*
 * =====================================================================================
 *
 *       Filename:  fscanf.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年01月23日 11时54分04秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    FILE *fp = fopen("./myfile", "w+");
    fprintf(fp, "%s%s%f", "str1", "str2", 1.2);
    //fflush(fp);
    rewind(fp);
    char str1[100];
    char str2[100];
    float f;
    printf("%s\n", "-------------");
    fscanf(fp, "%s%s%f", str1, str2, &f);
    printf("%s\n", str1);
    printf("%s\n", str2);
    printf("%f\n", f);
    fclose(fp);
    return 0;
}
