formater = "%r, %r, %r, %r"
print formater % (1, 2, 3, 4)
print formater % (formater, formater, formater, formater)
print """
        fdsafdsadfsa
        fdsafdasfdsafasdfsafdsa. fdsafdsa fdsad
        fdsafdsa
        'DDDSDDS'
        fdsafdsafsafsada
      """

print "how ?"
a1 = raw_input()
print "how 2 ?"
a2 = raw_input()

print a1 + a2





