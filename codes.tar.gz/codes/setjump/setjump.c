/*
 * =====================================================================================
 *
 *       Filename:  setjump.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2014年01月24日 11时15分24秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <setjmp.h>

jmp_buf gjmpbuf;
int longjp1() {
    printf("%s\n", "in longjp1()");
    longjmp(gjmpbuf, 1);
    return 0;
}

int main(int argc, char *argv[]) {

    printf("%s\n", "start set jump test");

    volatile int ret = setjmp(gjmpbuf);
    if(ret == 0) {
        printf("%s\n", "set jump ok");
    }  
    {
        longjp1();
        switch(ret) {
            case 1:
                printf("%s\n", "oh shit longjmp return the error");
                break;
            case 2:
                printf("%s\n", "2 return the error");
                break;
            default:
                break;
        }
    }
    return 0;
}
