import string
s = string.ascii_lowercase
e = enumerate(s)

print s
print list(e)
